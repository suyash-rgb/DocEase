package com.example.docease;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoceaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoceaseApplication.class, args);
	}

}
