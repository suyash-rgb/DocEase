package com.example.docease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoceaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
